## Connect Mr. AM 31 System to GitHub
1. Create a GitHub repo.
2. Clone and push all files.
3. Import AI voice & chatbot config.
