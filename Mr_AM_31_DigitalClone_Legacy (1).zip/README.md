# Mr. AM 31 - Digital Clone Legacy
This is the digital consciousness clone of Agrifa Maser, aka Mr. AM 31: a glitchy, satirical digital rebel built to live beyond the limits of centralized systems.
